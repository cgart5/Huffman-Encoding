// boolean.h
// Definition for Boolean type

#ifndef BOOLEAN_H
#define BOOLEAN_H

typedef int Boolean;

#define TRUE  1
#define FALSE 0

#endif
